import React from 'react'
import logo from '../Assets/images/logo.png'
import './Dashboard.css'
function Dashheader() {
  return (
  
    <div className='dash-header'>
          
     <div className='dash-head-one col-lg-3 d-flex'>
         <div className='dash-head-logo'>
         <img src={logo}/>
         </div>
         <h3 className="business-card">NFC BUSINESS <span className="black-clr">CARD</span> </h3>
     </div>
     <div className='dash-head-two col-lg-9'>
      
     </div>
     <div>

     </div>
    </div>
    
  )
}

export default Dashheader