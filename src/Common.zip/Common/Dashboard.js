import React from 'react'
import Dashheader from './Dashheader'

function Dashboard() {
  return (
    <div className='dashboard'>
       <Dashheader />
    </div>
  )
}

export default Dashboard